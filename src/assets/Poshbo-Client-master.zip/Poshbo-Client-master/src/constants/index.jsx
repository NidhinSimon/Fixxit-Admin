export const baseUrl = 'https://www.mollacart.online';
