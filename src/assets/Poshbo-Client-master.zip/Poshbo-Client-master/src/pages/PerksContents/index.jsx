export const availablePerks = [
  { name: 'Wifi', label: 'Wifi' },
  { name: 'Free parking', label: 'Free Parking spot' },
  { name: 'Swimming pool', label: 'Swimming pool' },
  { name: 'AC', label: 'Air conditioning' },
  { name: 'Tv', label: 'TV' },
  { name: 'Radio', label: 'Radio' },
  { name: 'Pets', label: 'Pets' },
  { name: 'Airport shuttle', label: 'Airport shuttle' },
  { name: 'Fitness center', label: 'Fitness center' },
];
